// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        //'password': 'n5sYGPfvr7hunpxR',
    },
	'database': 'mutipatientmonitor',
    'users_table': 'users'
};